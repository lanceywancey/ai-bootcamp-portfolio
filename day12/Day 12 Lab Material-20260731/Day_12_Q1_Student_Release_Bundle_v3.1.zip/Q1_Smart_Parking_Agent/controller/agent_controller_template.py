from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT))

from controller.controller_helpers import save_candidate, source_hash, write_final_state, write_trace
from mcp_tools.mcp_client import call_tool
from revisers import claude_reviser, simulated_reviser


def choose_next_action(state: dict, compile_result: dict, test_result: dict | None) -> tuple[str, str]:
    """TODO: return (action, reason). Actions: ACCEPT, REPAIR, STOP, ESCALATE."""
    # TODO: compilation failure should normally request REPAIR.
    # TODO: all tests passing should ACCEPT.
    # TODO: enforce the iteration budget.
    # TODO: escalate a repeated failure signature.
    raise NotImplementedError("Complete choose_next_action")


async def run_loop(mode: str, test_file: str, max_iterations: int) -> dict:
    source_path = ROOT / "workspace" / "settlement_engine.cpp"
    state = {"status": "RUNNING", "iteration": 0, "repairs": 0,
             "max_iterations": max_iterations, "failure_signatures": [], "candidate_hashes": []}
    save_candidate(source_path.read_text(encoding="utf-8"), 0)

    # TODO: implement the bounded observe-decide-act loop using:
    #   await call_tool("compile_cpp", {...})
    #   await call_tool("run_tests", {...})
    #   choose_next_action(...)
    #   simulated_reviser.revise(...) or claude_reviser.revise(...)
    #   save_candidate(...), write_trace(...), write_final_state(...)
    # Stop on ACCEPT, STOP, ESCALATE, or a repeated candidate hash.
    raise NotImplementedError("Complete run_loop")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reviser", choices=["simulated", "claude"], default="simulated")
    parser.add_argument("--tests", default="tests/example_tests.json")
    parser.add_argument("--max-iterations", type=int, default=4)
    args = parser.parse_args()
    asyncio.run(run_loop(args.reviser, args.tests, args.max_iterations))


if __name__ == "__main__":
    main()
