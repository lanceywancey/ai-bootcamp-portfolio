#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

struct Input {
    int parking_minutes;
    std::string vehicle_type;
    int import_wh;
    int import_rate_cents_per_kwh;
    int export_wh;
    int export_rate_cents_per_kwh;
    bool vehicle_v2g;
    bool station_v2g;
    bool owner_opt_in;
    int soc_after_export;
    int minimum_departure_soc;
};

struct Result {
    int parking_fee_cents;
    int import_cost_cents;
    int export_credit_cents;
    int net_amount_cents;
};

// TODO 1: validate all inputs and V2G export conditions.
void validate(const Input& input) {
    (void)input;
    throw std::logic_error("TODO: implement validate");
}

// TODO 2: calculate parking using the rules in specs/settlement_rules.txt.
int calculate_parking_fee(const Input& input) {
    (void)input;
    return 0;
}

// TODO 3: convert Wh and cents/kWh into rounded integer cents.
int calculate_energy_amount(int energy_wh, int rate_cents_per_kwh) {
    (void)energy_wh;
    (void)rate_cents_per_kwh;
    return 0;
}

// TODO 4: calculate the complete settlement. A negative net amount is valid.
Result calculate_settlement(const Input& input) {
    return {calculate_parking_fee(input), 0, 0, 0};
}

Input parse_arguments(int argc, char* argv[]) {
    if (argc != 12) {
        throw std::invalid_argument("expected 11 arguments");
    }
    return {
        std::stoi(argv[1]), argv[2], std::stoi(argv[3]), std::stoi(argv[4]),
        std::stoi(argv[5]), std::stoi(argv[6]), std::stoi(argv[7]) != 0,
        std::stoi(argv[8]) != 0, std::stoi(argv[9]) != 0,
        std::stoi(argv[10]), std::stoi(argv[11])
    };
}

int main(int argc, char* argv[]) {
    try {
        const Input input = parse_arguments(argc, argv);
        validate(input);
        const Result result = calculate_settlement(input);
        const std::string settlement = result.net_amount_cents < 0 ? "CREDIT" :
            (result.net_amount_cents > 0 ? "PAY" : "ZERO");
        std::cout << "{\"status\":\"ok\",\"parking_fee_cents\":"
                  << result.parking_fee_cents << ",\"import_cost_cents\":"
                  << result.import_cost_cents << ",\"export_credit_cents\":"
                  << result.export_credit_cents << ",\"net_amount_cents\":"
                  << result.net_amount_cents << ",\"settlement\":\""
                  << settlement << "\"}" << std::endl;
        return 0;
    } catch (const std::exception& error) {
        std::cout << "{\"status\":\"error\",\"error\":\""
                  << error.what() << "\"}" << std::endl;
        return 2;
    }
}
